const Device = require('../models/Device');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

const uploadDeviceData = async (req, res) => {
    try {
        const jsonData = JSON.parse(req.file.buffer.toString()); 
        const newDevice = new Device(jsonData);
        await newDevice.save(); 
        res.status(200).send('File uploaded and data saved successfully');
    } catch (error) {
        console.log("Error uploading file:", error); 
        res.status(500).send('Server error');
    }
};

module.exports = { uploadDeviceData, upload };
