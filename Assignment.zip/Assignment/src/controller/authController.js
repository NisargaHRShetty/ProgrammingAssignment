// const jwt = require('jsonwebtoken');
// const User = require('../models/user');
// require('dotenv').config({ path: 'config/dev.env' });

// const login = async (req, res) => {
//     const { userID, password } = req.body;
//     try {
//         const user = await User.findOne({ userID });
//         if (!user) return res.status(401).send('Invalid userID');
//         if (user.password !== password) return res.status(401).send('Invalid password');
//         const token = jwt.sign({ userID: user.userID, role: user.role }, process.env.JWT_SECRET);
//         res.json({ token });
//     } catch (error) {
//         res.status(500).send('Server error');
//     }
// };

// const register = async (req, res) => {
//     const { userID, password, role } = req.body;
//     try {
//         const newUser = new User({ userID, password, role });
//         await newUser.save();
//         res.status(201).send('User registered successfully');
//     } catch (error) {
//         res.status(500).send('Server error');
//     }
// };

// const getUserRoleById = async (req, res) => {
//     const { userID } = req.params; // Extracted from URL params
//     try {
//         const user = await User.findOne({ userID });
//         if (!user) return res.status(404).send('User not found');
//         res.json({ role: user.role });
//     } catch (error) {
//         res.status(500).send('Server error');
//     }
// };

// const getUserAccount = async (req, res) => {
//     const { userID } = req.params;
//     try {
//         const user = await User.findOne({ userID });
//         if (!user) return res.status(404).send('User not found');
//         res.json(user); // Returns the user object
//     } catch (error) {
//         res.status(500).send('Server error');
//     }
// };

// module.exports = { login, register, getUserRoleById, getUserAccount };


const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const fs = require('fs');
const User = require('../models/user');
require('dotenv').config({ path: 'config/dev.env' });

const login = async (req, res) => {
    const { userID, password } = req.body;
    try {
        const user = await User.findOne({ userID });
        if (!user) return res.status(401).send('Invalid userID');
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(401).send('Invalid password');
        const token = jwt.sign({ userID: user.userID, role: user.role, password }, process.env.JWT_SECRET);
        res.json({ token });
    } catch (error) {
        res.status(500).send('Server error');
    }
};

const register = async (req, res) => {
    const { userID, password, role, accountStatus } = req.body; 
    try {
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);
        const newUser = new User({ userID, password: hashedPassword, role, accountStatus }); 
        await newUser.save();
        res.status(201).send('User registered successfully');
    } catch (error) {
        console.log("Error during registration:", error); 
        res.status(500).send('Server error');
    }
};


const getUserRoleById = async (req, res) => {
    const { userID } = req.params;
    try {
        const user = await User.findOne({ userID });
        if (!user) return res.status(404).send('User not found');
        res.json({ role: user.role });
    } catch (error) {
        res.status(500).send('Server error');
    }
};

const getUserAccount = async (req, res) => {
    const { userID } = req.params;
    try {
        const user = await User.findOne({ userID });
        if (!user) return res.status(404).send('User not found');
        res.json({
            userID: user.userID,
            role: user.role,
            token: jwt.sign({ userID: user.userID, role: user.role, password: user.password }, process.env.JWT_SECRET)
        });
    } catch (error) {
        res.status(500).send('Server error');
    }
};

const getLogoImage = async (req, res) => {
    const logoPath = path.join(__dirname, '../images/hyperimage.png');
    res.sendFile(logoPath);
};

const getWelcomeImage = async (req, res) => {
    const welcomePath = path.join(__dirname, '../images/welcome.png');
    res.sendFile(welcomePath);
};

const getTableColumnValues = async (req, res) => {
    const { tableName, columnName } = req.query;
    try {
        const table = await mongoose.connection.collection(tableName).find({}).toArray();
        if (!table || table.length === 0) return res.status(404).send('Table not found or no data available');
        const columnValues = table.map(row => row[columnName]);
        res.json({ columnValues });
    } catch (error) {
        res.status(500).send('Server error');
    }
};

const getTableRowValues = async (req, res) => {
    const { userID, tableName } = req.query;
    try {
        const row = await mongoose.connection.collection(tableName).findOne({ userID });
        if (!row) return res.status(404).send('Row not found');
        res.json(row);
    } catch (error) {
        res.status(500).send('Server error');
    }
};

const getTableCellValues = async (req, res) => {
    const { userID, tableName, columnName } = req.query;
    try {
        const row = await mongoose.connection.collection(tableName).findOne({ userID });
        if (!row) return res.status(404).send('Row not found');
        const cellValue = row[columnName];
        if (!cellValue) return res.status(404).send('Cell not found');
        res.json({ cellValue });
    } catch (error) {
        res.status(500).send('Server error');
    }
};

const getFile = async (req, res) => {
    const { fileName } = req.params;
    const filePath = path.join(__dirname, '../uploads', fileName);
    try {
        if (fs.existsSync(filePath)) {
            res.sendFile(filePath);
        } else {
            res.status(404).send('File not found');
        }
    } catch (error) {
        res.status(500).send('Server error');
    }
};

const getAccountStatus = async (req, res) => {
    const { userID } = req.params;
    try {
        const user = await User.findOne({ userID });
        if (!user) return res.status(404).send('User not found');
        res.json({ accountStatus: user.accountStatus });
    } catch (error) {
        res.status(500).send('Server error');
    }
};

const getUserRolePermissions = async (req, res) => {
    const { role } = req.params;
    const permissionsMap = {
        admin: ["create", "read", "update", "delete"],
        user: ["read", "update"],
        viewer: ["read"]
    };
    try {
        if (!permissionsMap[role]) return res.status(404).send('Role not found');
        const permissions = permissionsMap[role];
        res.json({ permissions });
    } catch (error) {
        res.status(500).send('Server error');
    }
};
module.exports = { login, register, getUserRoleById, getUserAccount, getLogoImage, getWelcomeImage, getTableColumnValues, getTableRowValues, getTableCellValues, getFile, getAccountStatus, getUserRolePermissions};
