const jwt = require('jsonwebtoken');
const { findUserByCredentials } = require('../queries/userQueries');
require('dotenv').config({ path: 'config/dev.env' });

const loginService = async (userID, password) => {
    const user = await findUserByCredentials(userID, password);
    if (!user.userID) return null;
    if (!user.password) return null;
    const token = jwt.sign({ userID: user.userID, role: user.role }, process.env.JWT_SECRET);
    return token;
};

module.exports = { loginService };
