const mongoose = require('mongoose');

const deviceSchema = new mongoose.Schema({
    userID: { type: String, required: true },
    jsonData: { type: Object, required: true }
});

module.exports = mongoose.model('Device', deviceSchema);
