const User = require('../models/user');

const findUserByCredentials = async (userID, password) => {
    return await User.findOne({ userID, password });
};

const findUserByID = async (userID) => {
    return await User.findOne({ userID });
};

module.exports = { findUserByCredentials, findUserByID };
