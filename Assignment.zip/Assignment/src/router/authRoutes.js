const express = require('express');
const { login, register, getUserRoleById, getUserAccount, getLogoImage, getWelcomeImage, getTableColumnValues, getTableRowValues, getTableCellValues, getFile, getAccountStatus, getUserRolePermissions } = require('../controller/authController'); // Ensure correct import path
const verifyToken = require('../middleware/token');
const router = express.Router();

router.post('/login', login);
router.post('/register', register);
router.get('/role/:userID', getUserRoleById);
router.get('/account/:userID', getUserAccount); 
router.get('/logo', getLogoImage); 
router.get('/welcome', getWelcomeImage); 
router.get('/table/column', getTableColumnValues); 
router.get('/table/row', getTableRowValues); 
router.get('/table/cell', getTableCellValues);
router.get('/file/:fileName', getFile); 
router.get('/account/status/:userID', getAccountStatus);
router.get('/role/permissions/:role', getUserRolePermissions);

module.exports = router;
