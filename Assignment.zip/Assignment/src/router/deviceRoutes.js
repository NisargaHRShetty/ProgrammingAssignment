const express = require('express');
const { uploadDeviceData, upload } = require('../controller/deviceController');
const router = express.Router();

router.post('/upload', upload.single('file'), uploadDeviceData); // Route for uploading JSON file

module.exports = router;
