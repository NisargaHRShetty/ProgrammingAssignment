const express = require('express');
const dotenv = require('dotenv');
const connectDB = require('./db/mongoose');
const authRoutes = require('./router/authRoutes');
const deviceRoutes = require('./router/deviceRoutes');

dotenv.config();
connectDB(); 

const app = express();
app.use(express.json()); 

// Set up routes
app.use('/api/auth', authRoutes);
app.use('/api/devices', deviceRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
